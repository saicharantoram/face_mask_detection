# face_mask_detection
Face Mask Detection using Keras and pre-trained weights file. Run in Google Colab for output
